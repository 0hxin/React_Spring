function MainBeBenefitComponent(props) {
    return(
        <div className={'card promotionCard border-0 rounded-3'}>
            <img className={'card-img'} src={props.img} />
        </div>
    );
}
export default MainBeBenefitComponent